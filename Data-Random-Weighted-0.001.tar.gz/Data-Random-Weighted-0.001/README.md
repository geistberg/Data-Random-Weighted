Data-Random-Weighted
====================
